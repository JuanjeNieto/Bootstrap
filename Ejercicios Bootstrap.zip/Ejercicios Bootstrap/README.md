Bootstrap exercises for DAW2
